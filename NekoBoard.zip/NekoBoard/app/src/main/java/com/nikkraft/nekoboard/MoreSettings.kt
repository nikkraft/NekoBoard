@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.ui.text.ExperimentalTextApi::class
)

package com.nikkraft.nekoboard

import android.Manifest
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.graphics.Typeface as AndroidTypeface
import android.graphics.drawable.ColorDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt


// ============================================================================
// 16. НАСТРОЙКИ: ЯЗЫКИ И СЛОВАРИ, ИКОНКИ, ПАНЕЛЬ ИНСТРУМЕНТОВ
// ============================================================================

@Composable
internal fun MyanmarOrderSection(settings: KeyboardSettings) {
    val context = LocalContext.current
    SettingsSection("Бирманский") {
        ToggleItem(
            Icons.Rounded.Language, "ေ и ြ перед согласной",
            "Печатайте как видите на экране: в поле текст попадёт в правильном порядке Unicode. Выключите, если набираете согласную первой",
            settings.myanmarVisual
        ) { KeyboardPrefs.edit(context) { putBoolean("myanmar_visual", it) } }
    }
}

@Composable
internal fun LanguagesPage(settings: KeyboardSettings) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val enabled = Languages.enabled(settings)
    val dictVersion = Dictionaries.version
    val status = Dictionaries.status
    var query by remember { mutableStateOf("") }
    var layoutFor by remember { mutableStateOf<String?>(null) }
    var showAll by remember { mutableStateOf(false) }

    fun save(list: List<KeyboardLanguage>) =
        KeyboardPrefs.edit(context) { putString("languages", list.joinToString(",") { it.id }) }

    fun download(lang: KeyboardLanguage) {
        val code = lang.dict ?: return
        scope.launch {
            Dictionaries.download(context, code)
                .onSuccess { Toast.makeText(context, tr("Словарь «{0}»: {1} слов", lang.displayTitle(), it), Toast.LENGTH_SHORT).show() }
                .onFailure { Toast.makeText(context, tr("Не удалось скачать словарь: {0}", it.message), Toast.LENGTH_LONG).show() }
        }
    }

    SettingsSection("Включённые языки") {
        enabled.forEachIndexed { i, lang ->
            key(dictVersion, lang.id, lang.rows, lang.customLayout) {
                LanguageRow(
                    lang,
                    dictState(context, lang, status),
                    trailing = {
                        IconButton(onClick = { layoutFor = lang.id }) {
                            Icon(Icons.Rounded.Keyboard, tr("Раскладка"), tint = if (lang.customLayout) cs.primary else cs.onSurfaceVariant)
                        }
                        if (enabled.size > 1) {
                            var menu by remember { mutableStateOf(false) }
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, tr("Действия с языком")) }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    if (i > 0) DropdownMenuItem(text = { Text(tr("Выше")) }, onClick = {
                                        menu = false
                                        save(enabled.toMutableList().also { java.util.Collections.swap(it, i, i - 1) })
                                    })
                                    if (i < enabled.lastIndex) DropdownMenuItem(text = { Text(tr("Ниже")) }, onClick = {
                                        menu = false
                                        save(enabled.toMutableList().also { java.util.Collections.swap(it, i, i + 1) })
                                    })
                                    DropdownMenuItem(text = { Text(tr("Убрать")) }, onClick = {
                                        menu = false
                                        save(enabled - lang)
                                    })
                                }
                            }
                        }
                    },
                    onDict = { download(lang) }
                )
            }
        }
    }
    if (enabled.any { it.id == "my" }) MyanmarOrderSection(settings)
    SettingsSection("Добавить язык") {
        GroupItem {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                shape = RoundedCornerShape(24.dp),
                placeholder = { Text(tr("Поиск: немецкий, Deutsch, de…")) },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                singleLine = true
            )
        }
        val terms = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        // строка поиска языка собирается один раз, а не на каждую букву для всех 120 языков
        val searchKeys = remember(I18n.isEnglish, Languages.all.size) {
            Languages.all.associate {
                val english = Locale.forLanguageTag(it.locale).getDisplayName(Locale.ENGLISH)
                it.id to "${it.id}|${it.title}|${it.displayTitle()}|${it.spaceLabel}|$english".lowercase()
            }
        }
        val available = Languages.all.filter { it !in enabled }
            .filter { lang -> terms.all { searchKeys[lang.id]?.contains(it) == true } }
        // весь список (больше сотни строк) строится только по просьбе: страница открывается сразу
        val shown = if (terms.isNotEmpty() || showAll) available else available.take(LANGS_PREVIEW)
        shown.forEach { lang ->
                key(dictVersion, lang.id) {
                    LanguageRow(lang, dictState(context, lang, status, enabled = false), trailing = {
                        FilledTonalIconButton(onClick = {
                            save(enabled + lang)
                            if (settings.dictAutoDownload && lang.dict != null && !Dictionaries.isInstalled(context, lang.dict)) download(lang)
                        }) { Icon(Icons.Rounded.Add, "Добавить") }
                    }, onDict = null)
                }
            }
        if (shown.size < available.size) {
            ActionItem(Icons.Rounded.KeyboardArrowDown, tr("Показать все языки ({0})", available.size), null, onClick = { showAll = true })
        }
    }
    SettingsSection("Словари") {
        ToggleItem(Icons.Rounded.CloudDownload, "Скачивать словарь автоматически", "При добавлении языка и при первом наборе на нём", settings.dictAutoDownload) {
            KeyboardPrefs.edit(context) { putBoolean("dict_auto_download", it) }
        }
    }
    enabled.firstOrNull { it.id == layoutFor }?.let { lang -> LangLayoutDialog(lang) { layoutFor = null } }
}

private const val LANGS_PREVIEW = 12

private fun dictState(context: Context, lang: KeyboardLanguage, status: Map<String, String>, enabled: Boolean = true): String {
    if (lang.composer == Composer.PINYIN) return tr("Встроенный словарь пиньиня — 40 000 слов")
    if (lang.composer == Composer.KANA) return tr("Хирагана и катакана из латиницы")
    val code = lang.dict ?: return tr("Без словаря — подсказки из ваших слов")
    status[code]?.let { return if (it == "загрузка…") tr("Словарь загружается…") else tr("Ошибка: {0}", it) }
    return when {
        Dictionaries.bundled(context, code) -> tr("Словарь встроен")
        // в списке «Добавить язык» диск не трогаем: проверка файла для каждой из сотни строк тормозила прокрутку
        !enabled -> tr("Есть словарь подсказок")
        Dictionaries.isInstalled(context, code) -> tr("Словарь скачан")
        enabled -> tr("Словарь не скачан — нажмите, чтобы скачать")
        else -> tr("Есть словарь подсказок")
    }
}

@Composable
private fun LanguageRow(lang: KeyboardLanguage, state: String, trailing: @Composable RowScope.() -> Unit, onDict: (() -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    val error = state.startsWith(tr("Ошибка: {0}", ""))
    val canDownload = onDict != null && (state == tr("Словарь не скачан — нажмите, чтобы скачать") || error)
    GroupItem(onClick = if (canDownload) onDict else null) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(cs.secondaryContainer), contentAlignment = Alignment.Center) {
                Text(lang.label, color = cs.onSecondaryContainer, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            }
            Column(Modifier.weight(1f)) {
                Text(lang.displayTitle(), style = MaterialTheme.typography.titleMedium, color = cs.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    state, style = MaterialTheme.typography.bodySmall,
                    color = if (error) cs.error else if (canDownload) cs.primary else cs.onSurfaceVariant
                )
                if (lang.customLayout) {
                    Text(
                        tr("Своя раскладка: {0}", lang.rows.firstOrNull()?.take(6)?.joinToString("").orEmpty() + "…"),
                        style = MaterialTheme.typography.bodySmall, color = cs.primary
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, content = trailing)
        }
    }
}

// ----------------------------------------------------------------------- иконки

@Composable
internal fun DefaultSlotIcon(slot: String, tint: Color, size: Dp) {
    val v: ImageVector? = when (slot) {
        "back" -> Icons.AutoMirrored.Rounded.ArrowBack
        "mic" -> Icons.Outlined.Mic
        "plugins" -> Icons.Rounded.Extension
        "translate" -> Icons.Rounded.Translate
        "gif" -> Icons.Rounded.GifBox
        "clipboard" -> Icons.Rounded.ContentPaste
        "emoji" -> Icons.Rounded.EmojiEmotions
        "one_handed" -> Icons.Rounded.SwapHoriz
        "incognito" -> Icons.Rounded.VisibilityOff
        "settings" -> Icons.Rounded.Settings
        "hide" -> Icons.Rounded.KeyboardHide
        "send" -> Icons.AutoMirrored.Rounded.Send
        "search" -> Icons.Rounded.Search
        "done" -> Icons.Rounded.Check
        else -> null
    }
    when {
        v != null -> Icon(v, null, tint = tint, modifier = Modifier.size(size))
        slot == "menu" -> GlyphIcon(Glyph.GRID, tint, size)
        slot == "globe" -> GlyphIcon(Glyph.GLOBE, tint, size)
        slot == "emoji_key" -> GlyphIcon(Glyph.EMOJI, tint, size)
        slot == "shift" -> GlyphIcon(Glyph.SHIFT, tint, size)
        slot == "caps" -> GlyphIcon(Glyph.CAPS, tint, size)
        slot == "backspace" -> GlyphIcon(Glyph.BACKSPACE, tint, size)
        slot == "enter" -> GlyphIcon(Glyph.RETURN, tint, size)
        slot == "go" -> GlyphIcon(Glyph.ARROW, tint, size)
        slot == "layout_swap" -> LayoutSwapIcon(tint, size)
        slot == "emoji_recent" -> Icon(Icons.Rounded.History, null, tint = tint, modifier = Modifier.size(size))
        slot.startsWith("emoji_cat_") -> {
            // Вкладки эмодзи в настройках показываем векторными значками, как остальные иконки.
            val v = when (slot.removePrefix("emoji_cat_").toIntOrNull() ?: 0) {
                1 -> Icons.Rounded.People
                2 -> Icons.Rounded.Pets
                3 -> Icons.Rounded.Restaurant
                4 -> Icons.Rounded.Flight
                5 -> Icons.Rounded.SportsSoccer
                6 -> Icons.Rounded.Lightbulb
                7 -> Icons.Rounded.Favorite
                8 -> Icons.Rounded.Flag
                else -> Icons.Rounded.Mood
            }
            Icon(v, null, tint = tint, modifier = Modifier.size(size))
        }
    }
}

@Composable
internal fun IconsPage(settings: KeyboardSettings) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var target by remember { mutableStateOf<IconSlot?>(null) }
    var textFor by remember { mutableStateOf<IconSlot?>(null) }
    var menuFor by remember { mutableStateOf<IconSlot?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    // список из трёх десятков иконок нужен редко — раскрывается по нажатию
    var showIcons by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        val slot = target
        if (uri != null && slot != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { IconStore.setImage(context, slot.id, uri) }
            if (!ok) Toast.makeText(context, tr("Не удалось открыть картинку"), Toast.LENGTH_LONG).show()
        }
        target = null
    }
    val emojiFontLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val temp = File(context.cacheDir, "emoji_check.ttf")
                    context.contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { input.copyTo(it) } } ?: error("open")
                    requireNotNull(AndroidTypeface.Builder(temp).build())
                    temp.copyTo(File(context.filesDir, KeyboardPrefs.EMOJI_FONT_FILENAME), overwrite = true)
                    temp.delete()
                }.isSuccess
            }
            if (ok) KeyboardPrefs.setEmojiFont(context)
            else Toast.makeText(context, tr("Нужен файл шрифта .ttf с цветными эмодзи"), Toast.LENGTH_LONG).show()
        }
    }

    SettingsSection("Стиль эмодзи") {
        GroupItem { EmojiStylePicker(settings) { emojiFontLauncher.launch("*/*") } }
        ToggleItem(
            Icons.Rounded.Keyboard, "Возврат к буквам после эмодзи",
            "Как в Gboard: выбрали эмодзи — панель закрылась, и можно сразу печатать дальше",
            settings.emojiReturnToKeyboard
        ) { on -> KeyboardPrefs.edit(context) { putBoolean("emoji_return_keyboard", on) } }
        if (settings.emojiFontVersion != 0L) {
            ActionItem(
                Icons.Rounded.DeleteOutline, "Удалить свой шрифт эмодзи", null,
                onClick = { KeyboardPrefs.resetEmojiFont(context) }
            )
        }
    }
    SettingsSection("Свои иконки") {
        ActionItem(
            if (showIcons) Icons.Rounded.ExpandLess else Icons.Rounded.Brush,
            if (showIcons) "Скрыть список иконок" else "Заменить иконки кнопок",
            "Своя картинка или эмодзи вместо любой иконки: меню, микрофон, ⌫, Enter, вкладки эмодзи",
            onClick = { showIcons = !showIcons }
        )
    }
    if (showIcons) IconStore.slots.groupBy { it.group }.forEach { (group, slots) ->
        SettingsSection(group) {
            for (slot in slots) {
                val custom = IconStore.userIcon(slot.id)
                GroupItem(onClick = { menuFor = slot }) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                            SlotIcon(slot.id, cs.onPrimaryContainer, 24.dp) { DefaultSlotIcon(slot.id, cs.onPrimaryContainer, 24.dp) }
                        }
                        Column(Modifier.weight(1f)) {
                            Text(tr(slot.title), style = MaterialTheme.typography.titleMedium, color = cs.onSurface)
                            Text(
                                when (custom) {
                                    null -> tr(if (IconStore.get(slot.id) != null) "Из плагина" else "Стандартная")
                                    is CustomIcon.Picture -> tr(if (custom.tint) "Своя картинка · в цвет темы" else "Своя картинка")
                                    is CustomIcon.Label -> tr("Свой текст: {0}", custom.text)
                                },
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                            )
                        }
                        if (custom != null) {
                            IconButton(onClick = { IconStore.reset(context, slot.id) }) { Icon(Icons.Rounded.RestartAlt, "Вернуть стандартную") }
                        }
                    }
                }
            }
        }
    }
    if (showIcons) SettingsSection(null) {
        ActionItem(Icons.Rounded.RestartAlt, "Вернуть все иконки", null, onClick = { confirmReset = true })
    }

    menuFor?.let { slot ->
        val custom = IconStore.userIcon(slot.id)
        AlertDialog(
            onDismissRequest = { menuFor = null },
            icon = { SlotIcon(slot.id, cs.primary, 32.dp) { DefaultSlotIcon(slot.id, cs.primary, 32.dp) } },
            title = { Text(tr(slot.title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { target = slot; menuFor = null; imageLauncher.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Image, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(tr("Картинка из галереи"))
                    }
                    FilledTonalButton(onClick = { textFor = slot; menuFor = null }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.EmojiEmotions, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(tr("Эмодзи или текст"))
                    }
                    if (custom is CustomIcon.Picture) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Перекрашивать в цвет темы"), Modifier.weight(1f))
                            Switch(checked = custom.tint, onCheckedChange = { IconStore.setTint(context, slot.id, it) })
                        }
                    }
                    if (custom != null) {
                        OutlinedButton(onClick = { IconStore.reset(context, slot.id); menuFor = null }, modifier = Modifier.fillMaxWidth()) {
                            Text(tr("Вернуть стандартную"))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuFor = null }) { Text(tr("Готово")) } }
        )
    }
    textFor?.let { slot ->
        TextInputDialog(slot.title, (IconStore.userIcon(slot.id) as? CustomIcon.Label)?.text.orEmpty(), "Эмодзи или до 6 символов", onDismiss = { textFor = null }) { v ->
            if (v.isNotBlank()) IconStore.setText(context, slot.id, v.trim()) else IconStore.reset(context, slot.id)
            textFor = null
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text(tr("Вернуть все иконки?")) },
            text = { Text(tr("Свои картинки и тексты будут удалены.")) },
            confirmButton = { Button(onClick = { IconStore.resetAll(context); confirmReset = false }) { Text(tr("Вернуть")) } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text(tr("Отмена")) } }
        )
    }
}

// ----------------------------------------------------------------------- панель инструментов

@Composable
internal fun ToolbarPage(settings: KeyboardSettings) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val catalog = Toolbar.catalog()
    val byId = catalog.associateBy { it.id }
    val hidden = settings.toolbarHiddenSet
    val order = remember(catalog, settings.toolbarOrder) {
        Toolbar.arrange(catalog.map { it.id }, settings.toolbarOrderList, hidden, includeHidden = true)
    }
    fun saveOrder(list: List<String>) = KeyboardPrefs.edit(context) { putString("toolbar_order", list.joinToString(",")) }

    InfoCard(
        Icons.Rounded.DragIndicator,
        "Порядок кнопок на панели инструментов (кнопка с сеткой слева вверху). На самой клавиатуре порядок тоже " +
            "меняется: удерживайте кнопку и перетащите её влево или вправо."
    )
    SettingsSection("Размер") {
        SliderItem(
            icon = Icons.Rounded.Height, title = "Толщина верхней панели",
            value = settings.headerHeightDp, range = 40f..60f,
            format = { "${it.roundToInt()} dp" },
            onCommit = { v -> KeyboardPrefs.edit(context) { putFloat("header_height_dp", v) } }
        )
    }
    SettingsSection("Кнопка панели") {
        ToggleItem(
            Icons.Rounded.Apps, "Кнопка панели функций",
            if (!settings.showHeader) "Верхняя панель выключена"
            else if (settings.toolsButton) "Кнопка с сеткой слева от подсказок"
            else if (settings.showSuggestions) "Скрыта: панель функций появляется, когда поле пустое"
            else "Скрыта: подсказки выключены, поэтому панель функций видна всегда",
            settings.toolsButton
        ) { KeyboardPrefs.edit(context) { putBoolean("tools_button", it) } }
    }
    SettingsSection("Кнопки") {
        order.forEachIndexed { i, id ->
            val def = byId[id] ?: return@forEachIndexed
            val visible = id !in hidden
            GroupItem {
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(Modifier.size(40.dp).clip(CircleShape).background(if (visible) cs.secondaryContainer else cs.surfaceContainerHighest), contentAlignment = Alignment.Center) {
                        val tint = if (visible) cs.onSecondaryContainer else cs.outline
                        when {
                            def.slot != null && def.icon != null -> SlotIcon(def.slot, tint, 20.dp) { Icon(def.icon, null, tint = tint, modifier = Modifier.size(20.dp)) }
                            def.spec != null -> SpecIcon(def.spec, tint, 20.dp)
                        }
                    }
                    Text(
                        tr(def.title), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
                        color = if (visible) cs.onSurface else cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    IconButton(onClick = { saveOrder(order.toMutableList().also { java.util.Collections.swap(it, i, i - 1) }) }, enabled = i > 0) {
                        Icon(Icons.Rounded.KeyboardArrowUp, "Раньше")
                    }
                    IconButton(onClick = { saveOrder(order.toMutableList().also { java.util.Collections.swap(it, i, i + 1) }) }, enabled = i < order.lastIndex) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "Позже")
                    }
                    Switch(
                        checked = visible,
                        onCheckedChange = { on -> Toolbar.setHidden(context, if (on) hidden - id else hidden + id) }
                    )
                }
            }
        }
    }
    SettingsSection(null) {
        ActionItem(Icons.Rounded.RestartAlt, "Порядок по умолчанию", "Все кнопки снова видны", onClick = {
            KeyboardPrefs.edit(context) { remove("toolbar_order"); remove("toolbar_hidden") }
        })
    }
}

/** Стили эмодзи: системный, встроенные наборы картинок и свой шрифт. В каждой карточке — пример. */
@Composable
internal fun EmojiStylePicker(settings: KeyboardSettings, onCustom: () -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val font = remember(settings.emojiFontVersion) { FontRepository.emoji(context, settings.emojiFontVersion) }
    val options = listOf(EmojiStyles.SYSTEM to tr("Как в системе")) + EmojiStyles.builtIn.map { it.first to it.second } +
        (EmojiStyles.CUSTOM to tr("Свой шрифт…"))
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (id, title) ->
            val sel = settings.emojiStyle == id
            Column(
                Modifier.width(132.dp).clip(RoundedCornerShape(if (sel) 26.dp else 16.dp))
                    .background(if (sel) cs.primaryContainer else cs.surfaceContainerHigh)
                    .clickable {
                        if (id == EmojiStyles.CUSTOM && settings.emojiFontVersion == 0L) onCustom()
                        else KeyboardPrefs.edit(context) { putString("emoji_style", id) }
                    }
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf("😀", "😍", "🐱", "🍕").forEach { EmojiGlyph(it, 26.dp, id, font) }
                }
                Text(
                    title, style = MaterialTheme.typography.labelLarge, color = if (sel) cs.onPrimaryContainer else cs.onSurface,
                    maxLines = 2, minLines = 2
                )
            }
        }
    }
}

// ----------------------------------------------------------------------- своя раскладка языка

/** Сохранить ряды языка (null — вернуть раскладку языка). */
private fun saveLangLayout(context: Context, langId: String, rows: List<List<String>>?) {
    val stored = KeyboardPrefs.current(context).langLayouts
    val o = runCatching { JSONObject(stored.ifBlank { "{}" }) }.getOrDefault(JSONObject())
    if (rows == null) o.remove(langId) else o.put(langId, JSONArray(rows.map { JSONArray(it) }))
    KeyboardPrefs.edit(context) { putString("lang_layouts", if (o.length() == 0) "" else o.toString()) }
}

@Composable
internal fun LangLayoutDialog(lang: KeyboardLanguage, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val original = remember(lang.id) { Languages.original(lang.id) ?: lang }
    var text by remember(lang.id) { mutableStateOf(lang.rows.joinToString("\n", transform = Languages::rowToText)) }
    var pickingLayout by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val rows = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    val parsed = rows.map { Languages.parseRowText(it) }
    val error = when {
        parsed.isEmpty() -> tr("Нужен хотя бы один ряд")
        parsed.size > 5 -> tr("Не больше 5 рядов")
        parsed.any { it.size > 14 } -> tr("В ряду не больше 14 клавиш")
        else -> null
    }
    fun fill(rows: List<List<String>>) {
        text = rows.joinToString("\n", transform = Languages::rowToText)
        pickingLayout = false
    }
    if (pickingLayout) {
        val query = search.trim()
        val presets = Languages.presets.filter { (name, _) -> name.contains(query, ignoreCase = true) }
        val choices = remember(search, lang.id, Languages.extra) {
            Languages.all.filter {
                it.id != lang.id &&
                    listOf(it.displayTitle(), it.title, it.spaceLabel, it.id).any { label -> label.contains(query, ignoreCase = true) }
            }
        }
        AlertDialog(
            onDismissRequest = { pickingLayout = false },
            title = { Text(tr("Выбрать раскладку")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(search, { search = it }, label = { Text(tr("Название раскладки или языка")) },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (query.isNotEmpty() && choices.isEmpty() && presets.isEmpty()) Text(tr("Ничего не нашлось"))
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 300.dp)) {
                        if (query.isEmpty()) item {
                            ListItem(
                                headlineContent = { Text(tr("Как у языка")) },
                                modifier = Modifier.clickable { fill(original.rows) }
                            )
                        }
                        items(presets) { (name, rows) ->
                            ListItem(
                                headlineContent = { Text(name) },
                                modifier = Modifier.clickable { fill(rows.map(Languages::parseRowText)) }
                            )
                        }
                        items(choices, key = { it.id }) { choice ->
                            ListItem(
                                headlineContent = { Text(choice.displayTitle()) },
                                supportingContent = { Text(choice.rows.first().take(6).joinToString(" ")) },
                                modifier = Modifier.clickable { fill(choice.rows) }
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickingLayout = false }) { Text(tr("Назад")) } }
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Keyboard, null) },
        title = { Text(tr("Раскладка: {0}", lang.displayTitle())) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    tr("Словарь, подсказки и голосовой ввод остаются от языка — меняются только клавиши. Последний ряд получает Shift и ⌫."),
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                )
                OutlinedButton(onClick = { search = ""; pickingLayout = true }) { Text(tr("Выбрать раскладку")) }
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text(tr("Ряды — по одному в строке")) },
                    supportingText = { Text(error ?: tr("Буквы подряд: йцукен. Составные клавиши: sh ch ŋ. Одна составная клавиша: [\"sh\"].")) },
                    isError = error != null,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace),
                    shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val same = parsed == original.rows
                saveLangLayout(context, lang.id, if (same) null else parsed)
                onDismiss()
            }, enabled = error == null) { Text(tr("Сохранить")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Отмена")) } }
    )
}

private const val MY_WORDS_SHOWN = 200

/** «Мой словарь»: слова, которых нет в словаре языка (с диакритикой, имена, термины). */
@Composable
internal fun MyWordsPage(settings: KeyboardSettings) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val langs = Languages.enabled(settings)
    var langId by remember { mutableStateOf(langs.firstOrNull { it.id != "ru" && it.id != "en" }?.id ?: langs.firstOrNull()?.id.orEmpty()) }
    val lang = langs.firstOrNull { it.id == langId } ?: langs.firstOrNull() ?: return
    val code = lang.dict ?: lang.id
    var all by remember { mutableStateOf(WordPredictorEngine.readMyWords(context)) }
    var adding by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val words = all[code].orEmpty()
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val input = context.contentResolver.openInputStream(uri) ?: error(tr("Файл не открылся"))
                    // потоком: словарь на сотни мегабайт не должен попадать в память целиком
                    input.use { WordPredictorEngine.importMyWords(context, lang, it) }
                }
            }
            all = WordPredictorEngine.readMyWords(context)
            r.onSuccess { n ->
                val capped = all[code].orEmpty().size >= WordPredictorEngine.MAX_MY_WORDS
                val msg = when {
                    capped && n <= 0 -> tr("Словарь уже заполнен: {0} слов", WordPredictorEngine.MAX_MY_WORDS)
                    capped -> tr("Добавлено слов: {0}. Предел словаря — {1} слов", n, WordPredictorEngine.MAX_MY_WORDS)
                    n > 0 -> tr("Добавлено слов: {0}", n)
                    else -> tr("Нечего добавлять")
                }
                Toast.makeText(context, msg, if (capped) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(context, tr("Ошибка: {0}", it.message), Toast.LENGTH_LONG).show() }
        }
    }

    InfoCard(
        Icons.Rounded.MenuBook,
        "Добавьте слова, которых не хватает в словаре языка: с ударениями и диакритикой (você, ação), имена, термины. " +
            "Они появятся в подсказках и не будут исправляться. Можно добавить сразу несколько — через пробел или запятую."
    )
    if (langs.size > 1) {
        ChoiceItem(
            Icons.Rounded.Language, "Язык", null,
            langs.map { it.id to it.spaceLabel }, lang.id
        ) { langId = it }
    }
    SettingsSection(tr("Слова: {0}", words.size)) {
        ActionItem(Icons.Rounded.Add, "Добавить слова", lang.spaceLabel, onClick = { adding = true })
        ActionItem(Icons.Rounded.UploadFile, "Загрузить словарь из файла", "Файл .txt: слова по строкам или через пробел, подходит выгрузка Gboard", onClick = {
            runCatching { fileLauncher.launch(arrayOf("*/*")) }.onFailure {
                Toast.makeText(context, tr("На телефоне нет приложения для выбора файлов"), Toast.LENGTH_LONG).show()
            }
        })
        if (words.isNotEmpty()) ActionItem(Icons.Rounded.DeleteForever, "Удалить все слова", lang.spaceLabel, onClick = { confirmClear = true })
        // большой загруженный словарь целиком не показываем: длинный список тормозит страницу
        if (words.size > MY_WORDS_SHOWN) Text(
            tr("Показаны последние {0}", MY_WORDS_SHOWN), Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
        )
        words.take(MY_WORDS_SHOWN).forEach { w ->
            GroupItem {
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(w, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    IconButton(onClick = {
                        WordPredictorEngine.removeMyWord(context, lang, w)
                        all = WordPredictorEngine.readMyWords(context)
                    }) { Icon(Icons.Rounded.Close, tr("Удалить")) }
                }
            }
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr("Удалить все слова?")) },
            text = { Text(tr("Мой словарь языка «{0}» станет пустым", lang.spaceLabel)) },
            confirmButton = {
                Button(onClick = {
                    confirmClear = false
                    WordPredictorEngine.clearMyWords(context, lang)
                    all = WordPredictorEngine.readMyWords(context)
                }) { Text(tr("Удалить")) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(tr("Отмена")) } }
        )
    }
    if (adding) {
        TextInputDialog("Добавить слова", "", "Например: você ação coração", onDismiss = { adding = false }) { v ->
            adding = false
            val n = WordPredictorEngine.addMyWords(context, lang, v)
            all = WordPredictorEngine.readMyWords(context)
            Toast.makeText(context, if (n > 0) tr("Добавлено слов: {0}", n) else tr("Нечего добавлять"), Toast.LENGTH_SHORT).show()
        }
    }
}
