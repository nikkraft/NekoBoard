package com.nikkraft.nekoboard

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

// NekoBoard: высота клавиш по приложениям и язык по контексту.

/** «пакет=высота;пакет=высота» → карта. */
internal fun parseAppHeights(raw: String): LinkedHashMap<String, Float> {
    val out = LinkedHashMap<String, Float>()
    raw.split(';').forEach { part ->
        val i = part.indexOf('=')
        if (i <= 0) return@forEach
        val h = part.substring(i + 1).toFloatOrNull() ?: return@forEach
        out[part.substring(0, i)] = h.coerceIn(32f, 96f)
    }
    return out
}

internal fun encodeAppHeights(map: Map<String, Float>): String =
    map.entries.joinToString(";") { "${it.key}=${it.value}" }

/** Высота клавиш, заданная для приложения, или null — тогда общая. */
internal fun KeyboardSettings.heightFor(pkg: String): Float? =
    if (pkg.isEmpty() || appKeyHeights.isEmpty()) null else parseAppHeights(appKeyHeights)[pkg]

private const val LAST_APP_KEY = "last_app_pkg"

internal fun noteLastApp(context: android.content.Context, pkg: String) {
    if (pkg.isEmpty() || pkg == context.packageName) return
    val p = KeyboardPrefs.prefs(context)
    if (p.getString(LAST_APP_KEY, "") != pkg) p.edit().putString(LAST_APP_KEY, pkg).apply()
}

@Composable
internal fun AppKeyHeightsItem(settings: KeyboardSettings) {
    val context = LocalContext.current
    val map = parseAppHeights(settings.appKeyHeights)
    val last = KeyboardPrefs.prefs(context).getString(LAST_APP_KEY, "").orEmpty()
    fun save(m: Map<String, Float>) = KeyboardPrefs.edit(context) { putString("app_key_heights", encodeAppHeights(m)) }
    fun label(pkg: String): String = runCatching {
        val pm = context.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        map.entries.toList().forEach { (pkg, h) ->
            key(pkg) {
                SliderItem(
                    icon = Icons.Rounded.Height, title = label(pkg),
                    value = h, range = 32f..68f,
                    format = { "${it.roundToInt()} dp" },
                    onCommit = { v -> save(LinkedHashMap(map).also { it[pkg] = v }) }
                )
                ActionItem(Icons.Rounded.DeleteOutline, tr("Убрать: {0}", label(pkg)), null, onClick = {
                    save(LinkedHashMap(map).also { it.remove(pkg) })
                })
            }
        }
        if (last.isNotEmpty() && last !in map) {
            ActionItem(
                Icons.Rounded.AddCircleOutline, "Своя высота для последнего приложения",
                label(last),
                onClick = { save(LinkedHashMap(map).also { it[last] = settings.keyHeightDp }) }
            )
        } else if (last.isEmpty()) {
            InfoCard(Icons.Rounded.Info, "Откройте клавиатуру в нужном приложении и вернитесь сюда: оно появится в списке.")
        }
    }
}

@Composable
internal fun AutoLanguageItems(settings: KeyboardSettings) {
    val context = LocalContext.current
    ToggleItem(
        Icons.Rounded.Language, "Английский для адресов и паролей",
        "В полях почты, ссылок и паролей — английская раскладка; после них язык возвращается",
        settings.autoLangField
    ) { KeyboardPrefs.edit(context) { putBoolean("auto_lang_field", it) } }
    ToggleItem(
        Icons.Rounded.Apps, "Язык для каждого приложения",
        "Клавиатура запоминает, на каком языке вы печатаете в приложении",
        settings.autoLangApp
    ) { KeyboardPrefs.edit(context) { putBoolean("auto_lang_app", it) } }
}
